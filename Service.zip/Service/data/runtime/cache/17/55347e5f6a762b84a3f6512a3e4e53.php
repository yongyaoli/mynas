<?php
//000000000000
 exit();?>
think_serialize:a:2:{s:20:"portal/Article/index";a:1:{i:0;a:1:{s:4:"vars";a:1:{s:3:"cid";s:1:"1";}}}s:17:"portal/List/index";a:1:{i:0;a:1:{s:4:"vars";a:1:{s:2:"id";s:1:"1";}}}}