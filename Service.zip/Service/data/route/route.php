<?php	return array (
  'news/:id' => 
  array (
    0 => 'portal/Article/index?cid=1',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\d+',
      'cid' => '\\d+',
    ),
  ),
  'news' => 
  array (
    0 => 'portal/List/index?id=1',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\d+',
    ),
  ),
);