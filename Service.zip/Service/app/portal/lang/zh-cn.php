<?php
// +----------------------------------------------------------------------
// | ThinkCMF [ WE CAN DO IT MORE SIMPLE ]
// +----------------------------------------------------------------------
// | Copyright (c) 2013-2019 http://www.thinkcmf.com All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: 老猫 <thinkcmf@126.com>
// +----------------------------------------------------------------------
return [
    'ADMIN_TAG_ADD'    => '添加标签',
    'ADMIN_TAG_DELETE' => '删除标签',
    'ADMIN_TAG_INDEX'  => '标签列表',
    'SAVE_SUCCESS'     => '保存成功!',
    'DELETE_SUCCESS'   => '删除成功！',
    'ADD_SUCCESS'      => '添加成功',
    'DELETE_FAILED'    => '删除失败',
    'ADD_FAILED'       => '添加失败',
];

